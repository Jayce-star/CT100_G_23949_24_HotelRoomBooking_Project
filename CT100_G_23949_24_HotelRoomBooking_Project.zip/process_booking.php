<?php
/* =========================================================
   Sunrise Hotel - Server-side booking processor
   The amount is ALWAYS recalculated here; the value sent by
   JavaScript is never trusted.
   ========================================================= */

// ---------- Configuration (keep in sync with script.js) ----------
$ROOMS = [
    "single" => ["label" => "Single Room", "rate" => 3500, "capacity" => 1],
    "double" => ["label" => "Double Room", "rate" => 5000, "capacity" => 2],
    "family" => ["label" => "Family Room", "rate" => 7500, "capacity" => 4],
];
const BREAKFAST_RATE = 700;
const TRANSFER_FEE   = 2000;
const LATE_CHECKOUT_FEE = 2000;  // individual requirement (digit 9)
const MIN_NIGHTS     = 1;
const MAX_NIGHTS     = 14;

// ---------- Helpers ----------
function clean($value)
{
    return htmlspecialchars(trim((string)$value), ENT_QUOTES, "UTF-8");
}

function ksh($amount)
{
    return "KSh " . number_format($amount);
}

// Render validation errors without displaying unescaped user input.
function renderErrors(array $errors)
{
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Booking Error | Sunrise Hotel</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="error-box">
            <h2>Booking could not be processed</h2>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error) ?></li>
                <?php endforeach; ?>
            </ul>
            <a class="btn" href="booking.html">Go back to the booking form</a>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// ---------- Accept POST only ----------
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: booking.html");
    exit;
}

// ---------- Retrieve input ----------
$fullName     = trim($_POST["full_name"] ?? "");
$idNumber     = trim($_POST["id_number"] ?? "");
$email        = trim($_POST["email"] ?? "");
$phone        = trim($_POST["phone"] ?? "");
$checkIn      = trim($_POST["check_in"] ?? "");
$nights       = filter_var($_POST["nights"] ?? "", FILTER_VALIDATE_INT);
$roomKey      = $_POST["room_type"] ?? "";
$guests       = filter_var($_POST["guests"] ?? "", FILTER_VALIDATE_INT);
$breakfast    = (($_POST["breakfast"] ?? "no") === "yes");
$transfer     = (($_POST["transfer"] ?? "") === "yes");
$lateCheckout      = (($_POST["late_checkout"] ?? "") === "yes");
$transferType = trim($_POST["transfer_type"] ?? "");
$arrivalTime  = trim($_POST["arrival_time"] ?? "");
$jsTotal      = filter_var($_POST["estimated_total"] ?? 0, FILTER_VALIDATE_INT);

// ---------- Server-side validation ----------
$errors = [];

if ($fullName === "") {
    $errors[] = "Customer name is required.";
}
if ($idNumber === "") {
    $errors[] = "National ID / Passport number is required.";
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Email address is not valid.";
}
if (!preg_match('/^\d{10}$/', $phone)) {
    $errors[] = "Phone number must contain exactly 10 digits.";
}

// Reject malformed dates and check against the hotel's local calendar day.
$hotelTimezone = new DateTimeZone("Africa/Nairobi");
$checkInDate = DateTimeImmutable::createFromFormat("!Y-m-d", $checkIn, $hotelTimezone);
if (!$checkInDate || $checkInDate->format("Y-m-d") !== $checkIn) {
    $errors[] = "Check-in date is not valid.";
} elseif ($checkIn < (new DateTimeImmutable("now", $hotelTimezone))->format("Y-m-d")) {
    $errors[] = "Check-in date cannot be in the past.";
}

if ($nights === false || $nights < MIN_NIGHTS || $nights > MAX_NIGHTS) {
    $errors[] = "Number of nights must be between " . MIN_NIGHTS . " and " . MAX_NIGHTS . ".";
}
if (!isset($ROOMS[$roomKey])) {
    $errors[] = "Please select a valid room type.";
}
if ($guests === false || $guests <= 0) {
    $errors[] = "Number of guests must be greater than zero.";
} elseif (isset($ROOMS[$roomKey]) && $guests > $ROOMS[$roomKey]["capacity"]) {
    $errors[] = $ROOMS[$roomKey]["label"] . " allows a maximum of " .
                $ROOMS[$roomKey]["capacity"] . " guest(s).";
}

// Transfer information is required only when airport transfer is selected.
if ($transfer && !in_array($transferType, ["Pick-up on arrival", "Drop-off on departure", "Both pick-up and drop-off"], true)) {
    $errors[] = "Please select a valid airport transfer type.";
}
if ($transfer && !preg_match("/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/", $arrivalTime)) {
    $errors[] = "Please enter a valid transfer time.";
}

if (!empty($errors)) {
    renderErrors($errors);
}

// ---------- Independent bill calculation ----------
// Never trust the hidden JavaScript total: recalculate all charges on the server.
$room          = $ROOMS[$roomKey];
$roomCost      = $room["rate"] * $nights;
$breakfastCost = $breakfast ? BREAKFAST_RATE * $guests * $nights : 0;
$transferCost  = $transfer ? TRANSFER_FEE : 0;
$lateCheckoutCost   = $lateCheckout ? LATE_CHECKOUT_FEE : 0;
$total         = $roomCost + $breakfastCost + $transferCost + $lateCheckoutCost;

$mismatch = ($jsTotal !== $total);

// ---------- Booking details ----------
$checkOutDate = (clone $checkInDate)->modify("+" . $nights . " days");
$reference    = "SH-" . (new DateTimeImmutable("now", $hotelTimezone))->format("Ymd") . "-" . strtoupper(bin2hex(random_bytes(4)));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmed | Sunrise Hotel</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="site-header">
        <div class="container header-inner">
            <h1 class="logo">Sunrise Hotel</h1>
            <nav>
                <a href="index.html">Home</a>
                <a href="index.html#about">About</a>
                <a href="booking.html">Book a Room</a>
                <a href="index.html#contact">Contact</a>
            </nav>
        </div>
    </header>

    <main class="receipt">
        <h2>BOOKING SUMMARY</h2>
        <p>This summary is generated from your form submission; no reservation has been stored or sent to the hotel.</p>
        <p class="ref">Reference: <?= clean($reference) ?></p>

        <?php if ($mismatch): ?>
            <div class="notice">
                The estimate shown on the form (<?= ksh((int)$jsTotal) ?>) did not match our
                records. The amount below was recalculated by the server.
            </div>
        <?php endif; ?>

        <dl>
            <dt>Customer:</dt>          <dd><?= clean($fullName) ?></dd>
            <dt>ID / Passport:</dt>     <dd><?= clean($idNumber) ?></dd>
            <dt>Email:</dt>             <dd><?= clean($email) ?></dd>
            <dt>Phone:</dt>             <dd><?= clean($phone) ?></dd>
            <dt>Room:</dt>              <dd><?= clean($room["label"]) ?></dd>
            <dt>Guests:</dt>            <dd><?= (int)$guests ?></dd>
            <dt>Check-in:</dt>          <dd><?= $checkInDate->format("D, d M Y") ?></dd>
            <dt>Check-out:</dt>         <dd><?= $checkOutDate->format("D, d M Y") ?></dd>
            <dt>Number of Nights:</dt>  <dd><?= (int)$nights ?></dd>
            <dt>Breakfast:</dt>         <dd><?= $breakfast ? "Yes" : "No" ?></dd>
            <dt>Airport Transfer:</dt>  <dd><?= $transfer ? "Yes" : "No" ?></dd>
            <?php if ($transfer): ?>
                <dt>Transfer Details:</dt>
                <dd><?= clean($transferType) ?><?= $arrivalTime !== "" ? " at " . clean($arrivalTime) : "" ?></dd>
            <?php endif; ?>
            <dt>Late Checkout:</dt>   <dd><?= $lateCheckout ? "Yes" : "No" ?></dd>
        </dl>

        <table class="breakdown">
            <tr><td>Room (<?= (int)$nights ?> x <?= ksh($room["rate"]) ?>)</td><td><?= ksh($roomCost) ?></td></tr>
            <?php if ($breakfast): ?>
                <tr><td>Breakfast (<?= (int)$guests ?> x <?= (int)$nights ?> x <?= ksh(BREAKFAST_RATE) ?>)</td><td><?= ksh($breakfastCost) ?></td></tr>
            <?php endif; ?>
            <?php if ($transfer): ?>
                <tr><td>Airport transfer</td><td><?= ksh($transferCost) ?></td></tr>
            <?php endif; ?>
            <?php if ($lateCheckout): ?>
                <tr><td>Late checkout</td><td><?= ksh($lateCheckoutCost) ?></td></tr>
            <?php endif; ?>
        </table>

        <p class="grand-total">TOTAL AMOUNT: <?= ksh($total) ?></p>
        <p class="thanks">Thank you for choosing Sunrise Hotel.</p>
        <p class="center"><a class="btn" href="index.html">Back to Home</a></p>
    </main>

    <footer class="site-footer" id="contact">
        <div class="container footer-grid">
            <div>
                <h3>Sunrise Hotel</h3>
                <p>Wake up to a better stay.</p>
            </div>
            <div>
                <h3>How to Reach Us</h3>
                <address>
                    Sunrise Hotel, Hotel Road<br>
                    Nairobi, Kenya<br>
                    Phone: +254 700 000 000<br>
                    Email: <a href="mailto:info@sunrisehotel.example">info@sunrisehotel.example</a>
                </address>
            </div>
            <div>
                <h3>Front Desk Hours</h3>
                <p>Open 24 hours, every day.<br>Check-in: 2:00 PM<br>Check-out: 10:00 AM</p>
            </div>
            <div>
                <h3>Quick Links</h3>
                <ul class="footer-links">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="index.html#about">About</a></li>
                    <li><a href="booking.html">Book a Room</a></li>
                </ul>
            </div>
        </div>
        <p class="copyright">&copy; <?= date("Y") ?> Sunrise Hotel. All rights reserved.</p>
    </footer>
</body>
</html>
