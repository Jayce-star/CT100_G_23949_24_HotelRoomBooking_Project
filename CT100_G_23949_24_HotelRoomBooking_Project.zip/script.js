/* =========================================================
   Sunrise Hotel - Booking form logic
   Rates and capacities are kept in one place so they are
   easy to change (e.g. new room type, new rate, new limit).
   ========================================================= */

const ROOMS = {
    single: { label: "Single Room", rate: 3500, capacity: 1 },
    double: { label: "Double Room", rate: 5000, capacity: 2 },
    family: { label: "Family Room", rate: 7500, capacity: 4 }
};

const BREAKFAST_RATE = 700;   // per person per day
const TRANSFER_FEE = 2000;    // flat
const LATE_CHECKOUT_FEE = 2000;  // flat (individual requirement, digit 9)
const MIN_NIGHTS = 1;
const MAX_NIGHTS = 14;

/* ---------- Element references ---------- */
const form = document.getElementById("bookingForm");
const fullName = document.getElementById("fullName");
const idNumber = document.getElementById("idNumber");
const email = document.getElementById("email");
const phone = document.getElementById("phone");
const checkIn = document.getElementById("checkIn");
const nights = document.getElementById("nights");
const roomType = document.getElementById("roomType");
const guests = document.getElementById("guests");
const transfer = document.getElementById("transfer");
const lateCheckout = document.getElementById("lateCheckout");
const transferDetails = document.getElementById("transferDetails");
const capacityInfo = document.getElementById("capacityInfo");
const capacityWarning = document.getElementById("capacityWarning");
const summaryBody = document.getElementById("summaryBody");
const totalDisplay = document.getElementById("totalDisplay");
const estimatedTotal = document.getElementById("estimatedTotal");
const resetBtn = document.getElementById("resetBtn");

/* ---------- Helpers ---------- */
function formatKsh(amount) {
    return "KSh " + amount.toLocaleString("en-US");
}

// Read the selected breakfast option when calculating the booking total.
function wantsBreakfast() {
    return document.querySelector('input[name="breakfast"]:checked').value === "yes";
}

function setError(input, message) {
    document.getElementById(input.id + "Error").textContent = message;
    input.classList.add("invalid");
}

function clearError(input) {
    document.getElementById(input.id + "Error").textContent = "";
    input.classList.remove("invalid");
}

/* ---------- Function 1: capacity check (dynamic feature) ---------- */
function checkRoomCapacity() {
    const room = ROOMS[roomType.value];
    const guestCount = parseInt(guests.value, 10);

    if (!room) {
        capacityInfo.textContent = "";
        capacityWarning.textContent = "";
        return true;
    }

    capacityInfo.textContent = "Maximum guests for this room: " + room.capacity;
    guests.max = room.capacity;

    if (guestCount > room.capacity) {
        capacityWarning.textContent =
            "Warning: " + room.label + " allows only " + room.capacity +
            " guest(s). Please reduce guests or choose a bigger room.";
        return false;
    }
    capacityWarning.textContent = "";
    return true;
}

/* ---------- Function 2: bill calculator ---------- */
// Keep the displayed estimate consistent with the server-side pricing rules.
function calculateBill() {
    const room = ROOMS[roomType.value];
    const nightCount = parseInt(nights.value, 10);
    const guestCount = parseInt(guests.value, 10);

    const bill = { roomCost: 0, breakfastCost: 0, transferCost: 0, lateCheckoutCost: 0, total: 0 };
    if (!room || isNaN(nightCount) || nightCount < 1) {
        return bill;
    }

    bill.roomCost = room.rate * nightCount;
    if (wantsBreakfast() && !isNaN(guestCount) && guestCount > 0) {
        bill.breakfastCost = BREAKFAST_RATE * guestCount * nightCount;
    }
    if (transfer.checked) {
        bill.transferCost = TRANSFER_FEE;
    }
    if (lateCheckout.checked) {
        bill.lateCheckoutCost = LATE_CHECKOUT_FEE;
    }
    bill.total = bill.roomCost + bill.breakfastCost + bill.transferCost + bill.lateCheckoutCost;
    return bill;
}

/* ---------- Function 3: summary + total display (dynamic feature) ---------- */
function updateSummary() {
    const bill = calculateBill();
    const room = ROOMS[roomType.value];

    if (!room) {
        summaryBody.innerHTML = '<p class="muted">Select a room to see your summary.</p>';
    } else {
        const nightCount = parseInt(nights.value, 10) || 0;
        const guestCount = parseInt(guests.value, 10) || 0;
        let rows = "<table>";
        rows += "<tr><td>" + room.label + " (" + nightCount + " night(s) x " +
                formatKsh(room.rate) + ")</td><td>" + formatKsh(bill.roomCost) + "</td></tr>";
        if (wantsBreakfast()) {
            rows += "<tr><td>Breakfast (" + guestCount + " guest(s) x " + nightCount +
                    " day(s) x " + formatKsh(BREAKFAST_RATE) + ")</td><td>" +
                    formatKsh(bill.breakfastCost) + "</td></tr>";
        }
        if (transfer.checked) {
            rows += "<tr><td>Airport transfer</td><td>" + formatKsh(bill.transferCost) + "</td></tr>";
        }
        if (lateCheckout.checked) {
            rows += "<tr><td>Late checkout</td><td>" + formatKsh(bill.lateCheckoutCost) + "</td></tr>";
        }
        rows += "</table>";
        summaryBody.innerHTML = rows;
    }

    totalDisplay.textContent = formatKsh(bill.total);
    estimatedTotal.value = bill.total;
}

/* ---------- Function 4: show/hide transfer details (dynamic feature) ---------- */
function toggleTransferDetails() {
    transferDetails.classList.toggle("hidden", !transfer.checked);
}

/* ---------- Function 5: validation ---------- */
// Validate required fields and capacity before submitting to PHP.
function validateBooking() {
    let valid = true;
    [fullName, idNumber, email, phone, checkIn, nights, roomType, guests].forEach(clearError);

    if (fullName.value.trim() === "") {
        setError(fullName, "Please enter your full name.");
        valid = false;
    }

    if (idNumber.value.trim() === "") {
        setError(idNumber, "Please enter your National ID or Passport number.");
        valid = false;
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email.value.trim())) {
        setError(email, "Enter a valid email address (e.g. name@example.com).");
        valid = false;
    }

    if (!/^\d{10}$/.test(phone.value.trim())) {
        setError(phone, "Phone number must contain exactly 10 digits.");
        valid = false;
    }

    if (checkIn.value === "") {
        setError(checkIn, "Please select a check-in date.");
        valid = false;
    } else if (checkIn.value < todayString()) {
        setError(checkIn, "Check-in date cannot be in the past.");
        valid = false;
    }

    const nightCount = Number(nights.value);
    if (!Number.isInteger(nightCount) || nightCount < MIN_NIGHTS || nightCount > MAX_NIGHTS) {
        setError(nights, "Number of nights must be between " + MIN_NIGHTS + " and " + MAX_NIGHTS + ".");
        valid = false;
    }

    if (roomType.value === "") {
        setError(roomType, "Please select a room type.");
        valid = false;
    }

    const guestCount = Number(guests.value);
    if (!Number.isInteger(guestCount) || guestCount <= 0) {
        setError(guests, "Number of guests must be greater than zero.");
        valid = false;
    } else if (!checkRoomCapacity()) {
        setError(guests, "Guests exceed the capacity of the selected room.");
        valid = false;
    }

    return valid;
}

// Build a local calendar date (rather than UTC) for the minimum check-in date.
function todayString() {
    const d = new Date();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return d.getFullYear() + "-" + month + "-" + day;
}

/* =========================================================
   Events
   ========================================================= */

// change: room type selected -> show capacity, re-check, recalc
roomType.addEventListener("change", function () {
    checkRoomCapacity();
    updateSummary();
});

// input: guests / nights typed -> capacity warning and live bill
guests.addEventListener("input", function () {
    checkRoomCapacity();
    updateSummary();
});
nights.addEventListener("input", updateSummary);

// change: breakfast radios and late checkout checkbox -> live bill
document.querySelectorAll('input[name="breakfast"]').forEach(function (radio) {
    radio.addEventListener("change", updateSummary);
});
lateCheckout.addEventListener("change", updateSummary);

// change: transfer checkbox -> reveal extra options and update bill
transfer.addEventListener("change", function () {
    toggleTransferDetails();
    updateSummary();
});

// input: phone accepts digits only
phone.addEventListener("input", function () {
    phone.value = phone.value.replace(/\D/g, "");
});

// submit: block submission when invalid
form.addEventListener("submit", function (event) {
    updateSummary();
    if (!validateBooking()) {
        event.preventDefault();
        const firstInvalid = form.querySelector(".invalid");
        if (firstInvalid) { firstInvalid.focus(); }
    }
});

// click: clear form
resetBtn.addEventListener("click", function () {
    form.reset();
    [fullName, idNumber, email, phone, checkIn, nights, roomType, guests].forEach(clearError);
    capacityInfo.textContent = "";
    capacityWarning.textContent = "";
    toggleTransferDetails();
    updateSummary();
});

/* ---------- Initial state ---------- */
checkIn.min = todayString();
toggleTransferDetails();
updateSummary();
